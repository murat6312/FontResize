package com.example.fontresize;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button increaseTextSizeButton;
    private Button decreaseTextSizeButton;
    private float textSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        increaseTextSizeButton = findViewById(R.id.increaseTextSizeButton);
        decreaseTextSizeButton = findViewById(R.id.decreaseTextSizeButton);

        textSize = textView.getTextSize();

        increaseTextSizeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textSize += 2;
                textView.setTextSize(textSize);
            }
        });

        decreaseTextSizeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textSize -= 2;
                textView.setTextSize(textSize);
            }
        });
    }
}